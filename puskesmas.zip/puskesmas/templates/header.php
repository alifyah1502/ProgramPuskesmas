<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/styles.css">
    <title>Puskesmas Information System</title>
</head>
<body>
<header>
    <h1>Puskesmas Information System</h1>
    <nav>
        <ul>
            <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="pasien.php">Pasien</a></li>
            <!-- Add other menu items here -->
        </ul>
    </nav>
</header>