<footer>
    <p>&copy; 2024 Puskesmas Information System</p>
</footer>
</body>
</html>